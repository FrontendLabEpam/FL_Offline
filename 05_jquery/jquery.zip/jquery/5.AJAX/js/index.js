const createHTML = ({ albumId, title, thumbnailUrl }) => `<div>
  AlbumId: ${albumId}<br>
  <h4>${title}</h4>
  <img src="${thumbnailUrl}" alt="">
</div>`;

$.ajax({
    type: 'GET',
    url: 'https://jsonplaceholder.typicode.com/photos',
    data: { id: 1 },
    success: (response) => {
      console.log(response);
      $('.mbox').html(createHTML(response[0]));
    },
    error: (error) => {
      console.error(error)
    },
    complete: () => {
      console.info("Completed!");
    }
  });

// $.ajax({
//   type: 'GET',
//   url: 'https://jsonplaceholder.typicode.com/photos',
//   data: { id: 1 }
// }).then((response) => {
//   console.log(response);
//   $('.mbox').html(createHTML(response[0]));
// }).catch(err => {
//   console.error('ERROR: '+err.statusText);
// });
