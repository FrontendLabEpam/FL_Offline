// Event Handlers
// on(), off(), one(), trigger()
// const $count = $('#count');
// let count = 0;
//
// $("#btn").one("click", function(e) {
//   // console.log(e);
//   $count.text(++count);
// });
// $("#btn").trigger('click');
// $('#btn').click();

// Form Events
// focus(), blur(), change(), submit()

// $('#check').change((e) => {
//   console.log('Changed')
// })
//
// $('#form').submit(function(e) {
//   e.preventDefault();
// });

// Keyboard Events
// keydown(), keyup(), keypress() Ctrl, Shift, F1 -ignore
// $('#input').keypress(function(e) {
//   console.log(e.keyCode)
// });

// Mouse Events
// click(), dblclick(), hover()
// $("#btn").hover(
//   () => $count.text(++count),
//   () => $count.text(--count)
// );


// $('li').click(function() {
//   alert('click');
// });
//
// $('ul').append('<li>List item item</li>');
// $('ul').on('click', 'li', function() {
//   alert('click works!')
// })

// Event Object
// event.preventDefault(), event.stopPropagation(), event.target
