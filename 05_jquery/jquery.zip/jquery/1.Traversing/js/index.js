

// ******************************************************
// is(), not(), has()
// eq(), first(), last()
// find(), parent(), parents(), closest()
// children(), prev(), next(), siblings()
// ******************************************************

// $('[name="subscribe"]').is(":checked")
// $('.dropdown').is(".open")
// $('.dropdown').not('.open').css({background: "teal"})
// $('li').has(".subitem").css("color", "blue")

// $('li').eq(0).css("color", 'green');
// $('.dropdown').first().is(".open")

// $('ul').find('.subitem').css({fontSize: "24px"})
// $('li').css({fontSize: "24px"})
// const $ul = $("ul");
// $ul.find('.subitem').css({fontSize: "24px"})

// $('.subitem').parent().css({borderLeft: "5px solid teal"})
// $('.subitem').parent('ul').css({borderLeft: "5px solid teal"})
// $('.subitem').parents().css({borderLeft: "5px solid teal"})
// $('.subitem').parents('div').css({borderLeft: "5px solid teal"})
// $('.subitem').closest('.list').css({borderLeft: "5px solid teal"})

// $(".sublist").children().css({color: "red"});
// $('.subitem').prev().css({color: "purple"})
// $('.subitem').next().css({color: "purple"})
// $('.subitem').siblings().css({color: "purple"})
