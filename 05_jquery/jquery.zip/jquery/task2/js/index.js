const $list = $(".list");
const $input = $("#add-input");
const $add = $("#add-submit");

const todos = [
  {
    text: "Buy milk",
    done: false
  },
  {
    text: "Play with dog",
    done: true
  }
];

const createItem = ({ text, done }) => `<li class="item">
  <span class="item-text ${done ? 'done' : ''}">${text}</span>
  <button class="item-remove">Remove</button>
  </li>`;


const renderList = (items) => {
  let $content="";

  for (let i=0; i < items.length; i++) {
    $content += createItem(items[i]);
  }

  $list.html($content);
}

renderList(todos);

$(".list").on("click", ".item-text", function() {
  $(this).toggleClass("done");
});

$(".list").on("click", ".item-remove", function() {
  $(this).closest(".item").remove();
});

$add.click(function(e) {
  e.preventDefault();

  const item = {
    text: $input.val(),
    done: false
  };
  todos.push(item);

  const $item = createItem(item);
  $list.append($item);
  $input.val("");
});
