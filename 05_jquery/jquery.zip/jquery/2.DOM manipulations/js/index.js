// Attributes
// attr(), prop(), val(), data()
// removeAttr(), removeProp()

// Note: as lots of other methods, could be used as both getters and setters
// $('#input').attr('type');
// $('#input').attr('readonly', true);
// $('#input').val();
// $('#input').val('Zoidberg')
// $('#check').removeAttr('type');

// $('img').attr('src', 'img/1.jpg')
// $('img').data('cat')


// CSS
// css() // sets inline style. ( { 'top' : 5, 'right' : 4 } ) or ( 'top', 5 )
// addClass(), removeClass(), hasClass()
// toggleClass(),
// $(element).hasClass(class) ? removeClass(class) : addClass(class)

// $('img').css({borderWidth: 10})
// $('img').css("borderWidth")
// $('img').addClass("x2");
// $('img').removeClass("x2");
// $('img').toggleClass('x2');



// html(), text() // get/set html/text
// $('<div>') // create element
// append(), prepend() // insert specified content to the end/beginning of element
// after(), before() // insert content after/before element
// remove() // removes element from DOM
// height(), width() // get/set value
// clone() // create a deep copy of an element
// wrap() // wrap element with another element
// detach() // same as remove but keeps all jQuery related data

// $('.boxes').html('<h1>Boxes</h1>');
// $('.boxes').text('<h1>Boxes</h1>');

const $box1 = $('<div>')
        .attr("id", 'box1')
        .text("#box1")
        .addClass("box");
const $box2 = $('<div id="box2" class="box">#box2</div>');

// $('.boxes').append($box1)
// $('.boxes').prepend($box2)

// $('.boxes').before($box1)
// $('.boxes').after($box2)

// $('.boxes').width()
// $('.boxes').height()
// $('.boxes').height(100)

// const $clone = $('.boxes').clone()
// $('body').append($clone)

// $('.boxes').wrap('<div class="wrapper">')




$('li').click(function() {
  const id = $(this).data('id');
  console.log(`$('li').data('id') // ${id}`);
  $('img').attr('src', `img/${id}.jpg`)
})


$("#check").change(function() {
  var $input = $( this );
  $("p.check").html(
    "$('#check').attr( \"checked\" ): <b>" + $input.attr( "checked" ) + "</b><br>" +
    "$('#check').prop( \"checked\" ): <b>" + $input.prop( "checked" ) + "</b><br>" +
    "$('#check').is( \":checked\" ): <b>" + $input.is( ":checked" ) + "</b>" );
});


$('#form').submit(function(e) {
  e.preventDefault();
  $("#data").html($(this).serialize())
})
