// hide(), show(), toggle()
// fadeOut(), fadeIn(), fadeToggle()
// slideOut(), slideDown(), slideToggle()
// $('.box').hide();
// $('.box').show();
// $('.box').toggle();
// $('.box').fadeIn();
// $('.box').fadeOut();
// $('.box').slideDown("slow");
// $('.box').slideUp("fast", () => {
//   alert("completed")
// });
// $('.box').slideToggle();


// animate()
// $('.box').animate({
//   height: 50,
//   width: 50
// }, 5000);
