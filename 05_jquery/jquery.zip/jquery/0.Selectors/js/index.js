// $("#someId").css({"prop" : "value", "prop1" : "value1", ...});

// $("#foo").css({"color": "red"});
// $(".bar").css({"color": "green"});
// $("p + ul").css({color: "red"})

// ******************************************************
// :even, :odd, :first, :last, :not(), :empty
// :gt() /* all elements at an index greater then specified */
// :lt() /* all elements at an index less then specified */
// :hidden /* display: none, type="hidden", width & height = 0, ancestor is hidden */
// :visible /* are visible */
// :parent /* are parents to other elements, including text node */
// :contains() /* contain the specified text */
// :has() /* contain at least one element that matches the specified selector */
// ******************************************************
// $("li:even").css({color: "red"});

// ******************************************************
// :first-child, :last-child, :only-child, :first-of-type, :last-of-type,
// :only-of-type, :nth-child(), :nth-last-child(), :nth-last-of-type(),
// :nth-of-type()
// ******************************************************
// $("b:nth-last-of-type(1)").css({"color": "red"})
// $("b:last-of-type").css({"color": "red"})
// $("em:last-child").css({"color": "red"})
// $("b:only-child").css({"color": "red"})


// ******************************************************
// [name],
// [name|='value'] /* attribute equal to value or starting with "my" followed by a hyphen (-) */
// [name*='value'], [name~='value'],
// [name$='value'], [name^='value']
// [name!='value'] /* neither such attribute nor specified value */
// ******************************************************

// $('[id]').css({color: "red"})
// $('[name]').css({color: "red"})
// $('[name|="user"]').css({color: "red"})
// $('[name*="user"]').css({color: "red"})
// $('[name~="user"]').css({color: "red"})
// $('[name$="user"]').css({color: "red"})
// $('[name^="user"]').css({color: "red"})
// $('input[name!="user"]').css({color: "red"})

// ***************
// :button, :checkbox, :file, :image, :input, :password, :radio, :reset,
// :submit, :text, :disabled, :enabled, :focus, :checked, :selected
// ***************
