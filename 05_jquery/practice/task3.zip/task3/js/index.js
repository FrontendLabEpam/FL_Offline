// ****************
// $.ajax({
//     type: 'POST',
//     url: 'authorization.php',
//     data: { login: 'John', password: 'gfhjkm' },
//     success: onSuccess,
//     error: onError,
//     complete: onComplete
//   });


// url "https://reqres.in/api/users/${id}"
// get user by id after button clicked
// always console.info('request completed')
// if request failed, add red error text to .user
// if succeeded, add data to block ".user" using the following template
// <h4>User ${id}</h4>
// <p>${first_name} {$last_name}</p>
// <img src="${avatar}" alt="avatar"/>
